/* ============================================================
   Root app — state machine + deck screen + states
   ============================================================ */
const { useState:uA, useEffect:uEA, useRef:uRA, useCallback:uCA } = React;

/* ---------- Gold sparkle celebration ---------- */
function Sparkle({ go }){
  if(!go) return null;
  const bits = Array.from({length:14});
  return (
    <div className="sparkle" aria-hidden>
      {bits.map((_,i)=>{
        const a = (i/bits.length)*Math.PI*2;
        const r = 90 + (i%3)*44;
        return <span key={i} className="spark" style={{
          "--tx":`${Math.cos(a)*r}px`, "--ty":`${Math.sin(a)*r}px`,
          "--d":`${(i%5)*40}ms`, "--sz":`${6+(i%3)*4}px`
        }}/>;
      })}
      <span className="spark-heart"><Ic.heart s={40} fill="currentColor"/></span>
    </div>
  );
}

/* ---------- Loading deck (shimmer) ---------- */
function LoadingDeck(){
  return (
    <div className="deck-stage" dir="rtl">
      <div className="deck-area">
        <div className="card card-top loading-card">
          <Shimmer className="sh-full"/>
          <div className="card-top-row">
            <Shimmer className="sh-badge"/>
            <Shimmer className="sh-counter"/>
          </div>
          <div className="card-scrim">
            <Shimmer className="sh-line w70"/>
            <Shimmer className="sh-line w40"/>
          </div>
        </div>
      </div>
      <div className="deck-loadmsg">نُحمّل الذكريات…</div>
    </div>
  );
}

/* ---------- Error state ---------- */
function ErrorState({ onRetry }){
  return (
    <div className="screen state-screen" dir="rtl">
      <div className="state-ring err"><Ic.offline s={30}/></div>
      <div className="state-ar">تعذّر تحميل الذكريات</div>
      <div className="state-en eng">Something went wrong while loading</div>
      <button className="btn btn-primary" onClick={onRetry}><Ic.rewind s={18}/> إعادة المحاولة</button>
    </div>
  );
}

/* ---------- Deck screen ---------- */
function DeckScreen({ data, index, total, loved, onDecision, onOpen, reduced }){
  const visible = data.slice(index, index+3);
  const progress = index/data.length;
  const act = (kind)=>{
    const top = data[index];
    if(top && top.__act) top.__act(kind);
    else onDecision(kind, top);
  };
  return (
    <div className="deck-stage" dir="rtl">
      <div className="deck-topline">
        <Progress value={progress}/>
      </div>

      <div className="deck-area">
        {visible.map((m,i)=>(
          <SwipeCard key={m.id} mem={m}
            index={index + i + 1}
            total={data.length}
            isTop={i===0} depth={i}
            onDecision={onDecision} onOpen={onOpen} reduced={reduced}/>
        ))}
      </div>

      <div className="deck-controls">
        <ActionBtn kind="rewind" small label="رجوع" onClick={()=>onDecision("rewind")}/>
        <ActionBtn kind="skip"  label="تخطّي"  onClick={()=>act("skip")}/>
        <ActionBtn kind="love"  label="أحب"   onClick={()=>act("love")}/>
        <ActionBtn kind="super" small label="مميّز" onClick={()=>act("super")}/>
      </div>
      <div className="deck-legend">
        <span><b>اسحب يمين</b> أحب</span>
        <span><b>فوق</b> مميّز</span>
        <span><b>يسار</b> تخطّي</span>
      </div>
    </div>
  );
}

/* ---------- PWA install hint ---------- */
function PwaHint({ onClose }){
  return (
    <div className="pwa-hint" dir="rtl">
      <span className="pwa-ic"><Ic.install s={18}/></span>
      <div className="pwa-tx">
        <b>أضف التطبيق لشاشتك</b>
        <span className="eng">Add to Home Screen for the full experience</span>
      </div>
      <button className="pwa-x" onClick={onClose} aria-label="إغلاق"><Ic.close s={16}/></button>
    </div>
  );
}

/* ====================== ROOT ====================== */
function App(){
  const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const [phase, setPhase] = uA("landing"); // landing|loading|deck|error|end
  const [index, setIndex] = uA(0);
  const [loved, setLoved] = uA([]);
  const [supers, setSupers] = uA(new Set());
  const [history, setHistory] = uA([]);
  const [tags, setTags] = uA({});
  const [lightbox, setLightbox] = uA(null);
  const [showFavs, setShowFavs] = uA(false);
  const [toastMsg, setToastMsg] = uA(null);
  const [sparkle, setSparkle] = uA(false);
  const [offline, setOffline] = uA(false);
  const [pwa, setPwa] = uA(false);
  const toastT = uRA(null);

  const data = window.MEMORIES;

  const toast = uCA((t)=>{
    setToastMsg(t);
    clearTimeout(toastT.current);
    toastT.current = setTimeout(()=>setToastMsg(null), 2200);
  },[]);

  // PWA hint after entering deck
  uEA(()=>{
    if(phase==="deck"){
      const t = setTimeout(()=>setPwa(true), 4200);
      return ()=>clearTimeout(t);
    }
  },[phase]);

  const start = ()=>{
    setPhase("loading");
    setTimeout(()=> setPhase("deck"), reduced?300:1100);
  };

  const decide = (kind, mem)=>{
    if(kind==="rewind"){
      if(history.length===0) return;
      const prev = history[history.length-1];
      setHistory(h=>h.slice(0,-1));
      setLoved(l=>l.filter(m=>m.id!==prev.id));
      setSupers(s=>{ const n=new Set(s); n.delete(prev.id); return n; });
      setIndex(i=>Math.max(0,i-1));
      return;
    }
    if(!mem) return;
    setHistory(h=>[...h, mem]);
    if(kind==="love" || kind==="super"){
      setLoved(l=> l.find(m=>m.id===mem.id)? l : [...l, mem]);
      if(kind==="super") setSupers(s=> new Set(s).add(mem.id));
      if(!reduced){ setSparkle(true); setTimeout(()=>setSparkle(false), 900); }
    }
    const next = index+1;
    if(next >= data.length){ setTimeout(()=>setPhase("end"), reduced?100:320); }
    setIndex(next);
  };

  const toggleFav = (mem)=>{
    setLoved(l=> l.find(m=>m.id===mem.id)? l.filter(m=>m.id!==mem.id) : [...l, mem]);
  };
  const addTag = (id, pin)=>{
    setTags(t=>({...t, [id]:[...(t[id]||[]), pin]}));
    toast({msg:`تم وسم ${pin.name}`, icon:<Ic.tag s={15}/>});
  };

  const attendees = Array.from(new Set(Object.values(tags).flat().map(t=>t.name)));
  const restart = ()=>{ setIndex(0); setLoved([]); setSupers(new Set()); setHistory([]); setShowFavs(false); setPhase("deck"); };

  return (
    <div className="app-root">
      <div className="ambient"/><div className="grain"/>

      <div className="device">
        <OfflineBar show={offline}/>

        {phase==="landing" && <Landing onStart={start}/>}
        {phase==="loading" && <LoadingDeck/>}
        {phase==="error"   && <ErrorState onRetry={start}/>}
        {phase==="deck" &&
          <DeckScreen data={data} index={index} total={window.DECK_TOTAL}
            loved={loved} onDecision={decide} onOpen={setLightbox} reduced={reduced}/>}
        {phase==="end" &&
          <EndScreen lovedCount={loved.length} superCount={supers.size} attendees={attendees}
            onFavourites={()=>setShowFavs(true)} onShare={()=>toast({msg:"تمت المشاركة", icon:<Ic.share s={15}/>})}
            onRestart={restart}/>}

        {showFavs &&
          <Favourites favs={loved} supers={supers} onBack={()=>setShowFavs(false)}
            onOpen={setLightbox} toast={toast}/>}

        {lightbox &&
          <Lightbox mem={lightbox} onClose={()=>setLightbox(null)}
            onToggleFav={toggleFav} isFav={!!loved.find(m=>m.id===lightbox.id)}
            tags={tags} addTag={addTag} toast={toast}/>}

        <Sparkle go={sparkle}/>
        <Toast toast={toastMsg}/>
        {pwa && phase==="deck" && <PwaHint onClose={()=>setPwa(false)}/>}
      </div>

      {/* Desktop ambient side controls */}
      <button className="dev-offline" onClick={()=>setOffline(o=>!o)} title="محاكاة وضع عدم الاتصال">
        <Ic.offline s={15}/>
      </button>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App/>);
