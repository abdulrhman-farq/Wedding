/* ============================================================
   Shared UI components (React, Babel)
   Exported to window at end of file.
   ============================================================ */
const { useState, useRef, useEffect, useCallback } = React;

/* ---------- Icons (stroke, gold-tunable via currentColor) ---------- */
const Ic = {
  heart:(p)=> <svg viewBox="0 0 24 24" width={p.s||24} height={p.s||24} fill={p.fill||"none"} stroke="currentColor" strokeWidth={p.w||1.8} strokeLinejoin="round"><path d="M12 20.5S3.5 14.8 3.5 9.2A4.7 4.7 0 0 1 12 6.5a4.7 4.7 0 0 1 8.5 2.7c0 5.6-8.5 11.3-8.5 11.3Z"/></svg>,
  close:(p)=> <svg viewBox="0 0 24 24" width={p.s||24} height={p.s||24} fill="none" stroke="currentColor" strokeWidth={p.w||1.8} strokeLinecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>,
  star:(p)=> <svg viewBox="0 0 24 24" width={p.s||24} height={p.s||24} fill={p.fill||"none"} stroke="currentColor" strokeWidth={p.w||1.8} strokeLinejoin="round"><path d="M12 3.5l2.6 5.5 6 .8-4.4 4.2 1.1 6L12 17.6 6.7 20l1.1-6L3.4 9.8l6-.8z"/></svg>,
  rewind:(p)=> <svg viewBox="0 0 24 24" width={p.s||24} height={p.s||24} fill="none" stroke="currentColor" strokeWidth={p.w||1.8} strokeLinecap="round" strokeLinejoin="round"><path d="M11 7L6 12l5 5M18 7l-5 5 5 5"/></svg>,
  play:(p)=> <svg viewBox="0 0 24 24" width={p.s||24} height={p.s||24} fill="currentColor"><path d="M8 5.5v13l11-6.5z"/></svg>,
  video:(p)=> <svg viewBox="0 0 24 24" width={p.s||16} height={p.s||16} fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round"><rect x="3" y="6" width="12" height="12" rx="2"/><path d="M15 10l6-3v10l-6-3z"/></svg>,
  photo:(p)=> <svg viewBox="0 0 24 24" width={p.s||16} height={p.s||16} fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round"><rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="8.5" cy="10" r="1.6"/><path d="M5 18l4.5-4 3 2.5L16 12l3 3.5"/></svg>,
  tag:(p)=> <svg viewBox="0 0 24 24" width={p.s||18} height={p.s||18} fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round"><path d="M4 12V5a1 1 0 0 1 1-1h7l8 8-8 8z"/><circle cx="8.5" cy="8.5" r="1.4"/></svg>,
  back:(p)=> <svg viewBox="0 0 24 24" width={p.s||22} height={p.s||22} fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M9 6l6 6-6 6"/></svg>,
  share:(p)=> <svg viewBox="0 0 24 24" width={p.s||20} height={p.s||20} fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="6" cy="12" r="2.4"/><circle cx="17" cy="6" r="2.4"/><circle cx="17" cy="18" r="2.4"/><path d="M8.2 11l6.6-3.6M8.2 13l6.6 3.6"/></svg>,
  download:(p)=> <svg viewBox="0 0 24 24" width={p.s||20} height={p.s||20} fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M12 4v10m0 0l-4-4m4 4l4-4M5 19h14"/></svg>,
  link:(p)=> <svg viewBox="0 0 24 24" width={p.s||20} height={p.s||20} fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M9 15l6-6M10 7l1-1a4 4 0 0 1 6 6l-1 1M14 17l-1 1a4 4 0 0 1-6-6l1-1"/></svg>,
  check:(p)=> <svg viewBox="0 0 24 24" width={p.s||18} height={p.s||18} fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12.5l4.5 4.5L19 7"/></svg>,
  whatsapp:(p)=> <svg viewBox="0 0 24 24" width={p.s||20} height={p.s||20} fill="currentColor"><path d="M12 2a10 10 0 0 0-8.5 15.2L2 22l4.9-1.5A10 10 0 1 0 12 2Zm5.3 14.1c-.2.6-1.3 1.2-1.8 1.2-.5.1-1 .1-3.2-.8-2.7-1.1-4.4-3.9-4.5-4.1-.1-.2-1.1-1.4-1.1-2.7 0-1.3.7-1.9.9-2.2.2-.2.5-.3.7-.3h.5c.2 0 .4 0 .6.5l.8 2c.1.2 0 .4-.1.5l-.4.5c-.2.2-.3.4-.1.6.2.4.8 1.2 1.6 1.9 1 .8 1.7 1.1 2 1.2.2.1.4.1.5-.1l.7-.8c.2-.2.3-.2.6-.1l1.9.9c.3.1.4.2.5.3.1.2.1.6-.2 1.1Z"/></svg>,
  offline:(p)=> <svg viewBox="0 0 24 24" width={p.s||16} height={p.s||16} fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M3 3l18 18M8.5 8.6A8 8 0 0 0 5 11M12 5c2.6 0 5 1 6.8 2.6M2 8.8a13 13 0 0 1 3.2-2.2M19 12a8 8 0 0 0-2-1.5M9 15a4 4 0 0 1 5 0"/><circle cx="12" cy="19" r="1" fill="currentColor" stroke="none"/></svg>,
  plus:(p)=> <svg viewBox="0 0 24 24" width={p.s||18} height={p.s||18} fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><path d="M12 5v14M5 12h14"/></svg>,
  install:(p)=> <svg viewBox="0 0 24 24" width={p.s||18} height={p.s||18} fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><rect x="6" y="3" width="12" height="18" rx="2.5"/><path d="M12 7v6m0 0l-2.3-2.3M12 13l2.3-2.3"/></svg>
};

/* ---------- Monogram ---------- */
function Monogram({size=64}){
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" aria-hidden>
      <defs>
        <linearGradient id="mg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="var(--gold-bright)"/>
          <stop offset=".5" stopColor="var(--gold)"/>
          <stop offset="1" stopColor="var(--gold-deep)"/>
        </linearGradient>
      </defs>
      <circle cx="50" cy="50" r="46" fill="none" stroke="url(#mg)" strokeWidth="1.2" opacity=".6"/>
      <circle cx="50" cy="50" r="40" fill="none" stroke="url(#mg)" strokeWidth=".6" opacity=".35"/>
      <text x="50" y="60" textAnchor="middle" fontFamily="Aref Ruqaa, serif"
            fontSize="40" fill="url(#mg)">ع&amp;ر</text>
    </svg>
  );
}

/* ---------- Cinematic media art ---------- */
function MediaArt({ sceneKey, type, dur, playing, small }){
  const bg = window.SCENES[sceneKey] || window.SCENES.candle;
  return (
    <div className="media-art" style={{background:bg}}>
      <div className="media-grain"/>
      <div className="veil"/>
      {type==="video" && !small &&
        <div className="play-glyph" aria-label="play">
          <span className="play-ring"/>
          <Ic.play s={30}/>
        </div>}
      {type==="video" && small &&
        <div className="play-mini"><Ic.play s={13}/></div>}
    </div>
  );
}

/* ---------- Media badge (PHOTO / VIDEO) ---------- */
function MediaBadge({ type, dur }){
  return (
    <span className="badge">
      {type==="video" ? <Ic.video s={14}/> : <Ic.photo s={14}/>}
      <span className="badge-ar">{type==="video"?"فيديو":"صورة"}</span>
      <span className="badge-dot"/>
      <span className="eng badge-en">{type==="video"?"VIDEO":"PHOTO"}</span>
      {dur && <span className="badge-dur">{dur}</span>}
    </span>
  );
}

/* ---------- Counter ---------- */
function Counter({ index, total }){
  return (
    <span className="counter">
      <b>{window.toAr(index)}</b>
      <i>/</i>
      <span>{window.toAr(total)}</span>
    </span>
  );
}

/* ---------- Progress bar ---------- */
function Progress({ value }){
  return (
    <div className="progress" role="progressbar" aria-valuenow={Math.round(value*100)}>
      <div className="progress-fill" style={{width:`${value*100}%`}}/>
    </div>
  );
}

/* ---------- Circular action button ---------- */
function ActionBtn({ kind, onClick, small, label }){
  const map = {
    rewind:{cls:"act-rewind", node:<Ic.rewind s={small?18:22}/>},
    skip:  {cls:"act-skip",   node:<Ic.close  s={small?20:26}/>},
    super: {cls:"act-super",  node:<Ic.star   s={small?20:26}/>},
    love:  {cls:"act-love",   node:<Ic.heart  s={small?22:28}/>}
  }[kind];
  return (
    <button className={`act ${map.cls} ${small?"act-sm":""}`} onClick={onClick} aria-label={label}>
      <span className="act-ring"/>
      {map.node}
    </button>
  );
}

/* ---------- Swipe stamp ---------- */
function Stamp({ kind, opacity }){
  const t = {love:"أحب", skip:"تخطّي", super:"مميّز"}[kind];
  return <div className={`stamp stamp-${kind}`} style={{opacity}}>{t}</div>;
}

/* ---------- Toast ---------- */
function Toast({ toast }){
  if(!toast) return null;
  return (
    <div className={`toast toast-${toast.tone||"gold"}`} role="status">
      {toast.icon}
      <span>{toast.msg}</span>
    </div>
  );
}

/* ---------- Offline indicator ---------- */
function OfflineBar({ show }){
  return (
    <div className={`offline ${show?"on":""}`} role="status">
      <Ic.offline s={15}/>
      <span>أنت غير متصل · سيُحفظ تفاعلك</span>
    </div>
  );
}

/* ---------- Shimmer block ---------- */
function Shimmer({ className, style }){
  return <div className={`shimmer ${className||""}`} style={style}/>;
}

/* ---------- Ornament row ---------- */
function Orn(){
  return <div className="orn"><span className="rule"/><span className="diamond"/><span className="rule"/></div>;
}

Object.assign(window, {
  Ic, Monogram, MediaArt, MediaBadge, Counter, Progress,
  ActionBtn, Stamp, Toast, OfflineBar, Shimmer, Orn
});
