/* ============================================================
   Moment data + cinematic media placeholder art
   (self-contained CSS scenes — swap for real media later)
   ============================================================ */

// Arabic-Indic numerals
window.toAr = (n)=> String(n).replace(/\d/g, d => "٠١٢٣٤٥٦٧٨٩"[d]);

// Each "scene" is a layered-gradient placeholder evoking a moment.
// bg: base wash · spots: bokeh/candles · tint: hue family
function scene(base, spots, vignette){
  return `${spots}, ${base}`;
}

const SCENES = {
  candle: scene(
    "linear-gradient(160deg,#1a1206,#2a1c0a 45%,#0e0a05)",
    "radial-gradient(40% 30% at 28% 30%,rgba(233,212,154,.55),transparent 60%), radial-gradient(30% 24% at 70% 22%,rgba(203,164,90,.5),transparent 60%), radial-gradient(50% 40% at 50% 95%,rgba(140,111,59,.4),transparent 70%)"
  ),
  emerald: scene(
    "linear-gradient(165deg,#0c1f18,#10342708 0,#0a1813)",
    "radial-gradient(45% 35% at 30% 25%,rgba(63,141,108,.5),transparent 60%), radial-gradient(35% 30% at 78% 70%,rgba(31,86,65,.6),transparent 60%), radial-gradient(30% 24% at 60% 40%,rgba(233,212,154,.22),transparent 60%)"
  ),
  rose: scene(
    "linear-gradient(160deg,#2a1410,#3a1d18 50%,#140a08)",
    "radial-gradient(40% 30% at 24% 28%,rgba(201,139,122,.55),transparent 60%), radial-gradient(34% 28% at 74% 64%,rgba(201,139,122,.35),transparent 60%), radial-gradient(50% 40% at 55% 90%,rgba(140,80,70,.4),transparent 70%)"
  ),
  bokeh: scene(
    "linear-gradient(180deg,#0d0a06,#160f08 60%,#0a0805)",
    "radial-gradient(14% 14% at 22% 30%,rgba(233,212,154,.7),transparent 60%), radial-gradient(10% 10% at 40% 22%,rgba(203,164,90,.55),transparent 60%), radial-gradient(18% 18% at 72% 38%,rgba(233,212,154,.4),transparent 60%), radial-gradient(8% 8% at 58% 60%,rgba(255,247,228,.6),transparent 60%), radial-gradient(12% 12% at 82% 72%,rgba(203,164,90,.4),transparent 60%)"
  ),
  ivory: scene(
    "linear-gradient(160deg,#2b2417,#3c3320 55%,#15110b)",
    "radial-gradient(42% 34% at 32% 30%,rgba(243,234,215,.4),transparent 60%), radial-gradient(34% 28% at 74% 66%,rgba(203,164,90,.32),transparent 60%)"
  ),
  dusk: scene(
    "linear-gradient(175deg,#241406,#3a230c 38%,#10243a)",
    "radial-gradient(60% 40% at 50% 18%,rgba(233,180,120,.45),transparent 65%), radial-gradient(40% 30% at 30% 85%,rgba(31,86,65,.4),transparent 70%)"
  ),
  night: scene(
    "linear-gradient(180deg,#0a0c12,#0e1018 60%,#070809)",
    "radial-gradient(8% 8% at 30% 24%,rgba(233,212,154,.7),transparent 60%), radial-gradient(6% 6% at 50% 16%,rgba(255,247,228,.6),transparent 60%), radial-gradient(7% 7% at 70% 28%,rgba(203,164,90,.6),transparent 60%), radial-gradient(40% 30% at 50% 96%,rgba(203,164,90,.3),transparent 70%)"
  )
};

// The deck. Display counter uses a large flavour total; deck plays through real cards.
window.MEMORIES = [
  {id:"m01", type:"photo", scene:"candle",  ar:"بسم الله، وبدأت الحكاية", en:"In His name, the story begins"},
  {id:"m02", type:"photo", scene:"ivory",   ar:"أوّل نظرة", en:"The first look"},
  {id:"m03", type:"video", scene:"emerald", ar:"الزفّة", en:"The procession", dur:"٠:٤٨"},
  {id:"m04", type:"photo", scene:"rose",    ar:"القهوة والورد", en:"Coffee & roses"},
  {id:"m05", type:"photo", scene:"bokeh",   ar:"ضحكة العمر", en:"A laugh to remember"},
  {id:"m06", type:"video", scene:"candle",  ar:"العقد", en:"The vow", dur:"١:١٢"},
  {id:"m07", type:"photo", scene:"dusk",    ar:"تحت ضوء المغرب", en:"Under the sunset"},
  {id:"m08", type:"photo", scene:"emerald", ar:"بين الأهل", en:"Among loved ones"},
  {id:"m09", type:"video", scene:"night",   ar:"رقصة العمر", en:"Dance of a lifetime", dur:"٢:٠٥"},
  {id:"m10", type:"photo", scene:"rose",    ar:"دموع الفرح", en:"Tears of joy"},
  {id:"m11", type:"photo", scene:"bokeh",   ar:"الأنوار والأمنيات", en:"Lights & wishes"},
  {id:"m12", type:"photo", scene:"ivory",   ar:"الكعكة", en:"The cake"},
  {id:"m13", type:"video", scene:"candle",  ar:"دعوات بالخير", en:"Blessings & duʿaa", dur:"٠:٣٦"},
  {id:"m14", type:"photo", scene:"night",   ar:"آخر رقصة", en:"The last dance"},
  {id:"m15", type:"photo", scene:"dusk",    ar:"وإلى العمر كلّه", en:"To a lifetime together"}
];

window.SCENES = SCENES;
window.DECK_TOTAL = 491; // flavour counter as in brief

// People available for tagging
window.PEOPLE = ["عبدالرحمن","رويدا","أبو عبدالرحمن","أم رويدا","نورة","سارة","فيصل","العمّ سعد"];
