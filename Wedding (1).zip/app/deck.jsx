/* ============================================================
   Swipe deck — gesture physics
   GESTURE RULE (do not mirror in RTL):
     physical right = love · left = skip · up = super
   ============================================================ */
const { useState:useS2, useRef:useR2, useEffect:useE2, useCallback:useC2 } = React;

function SwipeCard({ mem, index, total, isTop, depth, onDecision, onOpen, reduced }){
  const [drag, setDrag] = useS2({x:0,y:0,active:false});
  const start = useR2(null);
  const last = useR2({t:0,x:0,y:0,vx:0,vy:0});
  const [fly, setFly] = useS2(null); // {x,y,rot}

  const THRESH = 96;

  const onDown = (e)=>{
    if(!isTop || fly) return;
    const p = e.touches? e.touches[0] : e;
    start.current = {x:p.clientX, y:p.clientY};
    last.current = {t:performance.now(), x:p.clientX, y:p.clientY, vx:0, vy:0};
    setDrag(d=>({...d, active:true}));
  };
  const onMove = (e)=>{
    if(!start.current) return;
    const p = e.touches? e.touches[0] : e;
    const x = p.clientX - start.current.x;
    const y = p.clientY - start.current.y;
    const now = performance.now();
    const dt = Math.max(1, now - last.current.t);
    last.current = {
      t:now, x:p.clientX, y:p.clientY,
      vx:(p.clientX - last.current.x)/dt,
      vy:(p.clientY - last.current.y)/dt
    };
    setDrag({x, y, active:true});
  };
  const onUp = ()=>{
    if(!start.current) return;
    const {x,y} = drag;
    const {vx,vy} = last.current;
    start.current = null;
    const up = (y < -THRESH) || (vy < -.9 && y < -30);
    const right = (x > THRESH) || (vx > .7 && x > 20);
    const left = (x < -THRESH) || (vx < -.7 && x < -20);

    if(up && Math.abs(y) > Math.abs(x)){ fling("super", {x:x*1.2, y:-900, rot:x*0.05}); }
    else if(right){ fling("love", {x:1000, y:y+60, rot:22}); }
    else if(left){ fling("skip", {x:-1000, y:y+60, rot:-22}); }
    else { setDrag({x:0,y:0,active:false}); } // spring back
  };
  const fling = (kind, vec)=>{
    setDrag(d=>({...d, active:false}));
    setFly(vec);
    setTimeout(()=> onDecision(kind, mem), reduced?60:260);
  };

  // programmatic decision (buttons)
  useE2(()=>{
    if(!isTop) return;
    mem.__act = (kind)=>{
      const vec = kind==="love"?{x:1000,y:30,rot:22}
        : kind==="skip"?{x:-1000,y:30,rot:-22}
        : {x:0,y:-900,rot:0};
      fling(kind, vec);
    };
  },[isTop]);

  const x = fly? fly.x : drag.x;
  const y = fly? fly.y : drag.y;
  const rot = fly? fly.rot : drag.x*0.05;
  const dragging = drag.active && !fly;

  const loveOp = Math.max(0, Math.min(1, drag.x/THRESH));
  const skipOp = Math.max(0, Math.min(1, -drag.x/THRESH));
  const superOp = Math.max(0, Math.min(1, -drag.y/THRESH));

  // peeking transform for stacked cards
  const peek = {
    transform:`translateY(${depth*14}px) scale(${1-depth*0.05})`,
    opacity: depth>2?0:1,
    filter: depth>0? `brightness(${1-depth*0.12})` : "none"
  };
  const topStyle = {
    transform:`translate(${x}px,${y}px) rotate(${rot}deg)`,
    transition: dragging? "none"
      : fly? `transform ${reduced?.08:.36}s ${reduced?'linear':'cubic-bezier(.16,1,.3,1)'}`
      : "transform .5s cubic-bezier(.34,1.56,.64,1)",
    cursor: dragging?"grabbing":"grab"
  };

  return (
    <article
      className={`card ${isTop?"card-top":"card-peek"}`}
      style={isTop? topStyle : peek}
      onPointerDown={isTop?onDown:undefined}
      onPointerMove={isTop&&drag.active?onMove:undefined}
      onPointerUp={isTop?onUp:undefined}
      onPointerCancel={isTop?onUp:undefined}
      aria-hidden={!isTop}
    >
      <MediaArt sceneKey={mem.scene} type={mem.type} dur={mem.dur}/>

      {isTop && <>
        <Stamp kind="love" opacity={loveOp}/>
        <Stamp kind="skip" opacity={skipOp}/>
        <Stamp kind="super" opacity={superOp}/>
      </>}

      <div className="card-top-row">
        <MediaBadge type={mem.type} dur={mem.dur}/>
        {isTop && <Counter index={index} total={total}/>}
      </div>

      <div className="card-scrim">
        <div className="card-cap-ar">{mem.ar}</div>
        <div className="card-cap-en eng">{mem.en}</div>
        {isTop &&
          <button className="card-open" onClick={(e)=>{e.stopPropagation(); onOpen(mem);}}>
            التفاصيل · Open
          </button>}
      </div>
    </article>
  );
}

window.SwipeCard = SwipeCard;
