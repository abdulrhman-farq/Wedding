/* ============================================================
   Gallery — root app, tabs, selection, photo view
   ============================================================ */
const { useState:gS, useRef:gR, useEffect:gE, useCallback:gC, useMemo:gMemo } = React;
const M2 = window.GM, trG = window.toArG;

/* ---------- Density segmented control ---------- */
function DensitySeg({ value, onChange }){
  const opts=[["compact",<M2.gridC/>],["comfortable",<M2.gridM/>],["large",<M2.gridL/>]];
  return (
    <div className="seg" role="tablist" aria-label="كثافة العرض">
      {opts.map(([k,ic])=>(
        <button key={k} className={value===k?"on":""} onClick={()=>onChange(k)} aria-selected={value===k}>{ic}</button>
      ))}
    </div>
  );
}

/* ---------- Bottom nav ---------- */
function Nav({ tab, onTab }){
  const items=[
    ["photos","الصور", M2.photoF, M2.photoO],
    ["search","بحث", M2.search, M2.searchO],
    ["library","المكتبة", M2.libF, M2.libO]
  ];
  return (
    <nav className="nav">
      {items.map(([k,label,Fi,Oi])=>{
        const active=tab===k;
        const Icon=active?Fi:Oi;
        return (
          <button key={k} className={`nav-item ${active?"active":""}`} onClick={()=>onTab(k)}>
            <span className="pill"><Icon s={24}/></span>
            <span>{label}</span>
          </button>
        );
      })}
    </nav>
  );
}

/* ---------- Photo full view ---------- */
function PhotoView({ item, onClose, fav, onFav }){
  return (
    <div className="pv" role="dialog" aria-modal="true">
      <div className="pv-top">
        <button className="selbar-btn" onClick={onClose}><M2.back s={24}/></button>
        <div className="pv-title">
          {item.ar && <b>{item.ar}</b>}
          <span>{item.type==="video"?"فيديو":"صورة"}{item.dur?` · ${item.dur}`:""}</span>
        </div>
        <button className="selbar-btn" onClick={onFav} style={{color:fav?"var(--blue)":"var(--on-surface)"}}>
          {fav? <M2.heart s={22}/> : <M2.fav s={22}/>}
        </button>
        <button className="selbar-btn"><M2.more s={24}/></button>
      </div>
      <div className="pv-stage">
        <div className="pv-img" style={window.phStyle(item.tone)}>
          {item.type==="video" &&
            <div className="pv-play"><M2.play s={30}/></div>}
        </div>
      </div>
      <div className="pv-actions">
        <button><M2.share s={22}/><span>مشاركة</span></button>
        <button onClick={onFav}>{fav?<M2.heart s={22}/>:<M2.fav s={22}/>}<span>مفضّلة</span></button>
        <button><M2.add s={22}/><span>ألبوم</span></button>
        <button><M2.trash2 s={22}/><span>حذف</span></button>
      </div>
    </div>
  );
}

/* ---------- Search tab ---------- */
function SearchTab({ onFace }){
  const faces=window.G_FACES, cats=window.G_CATS;
  return (
    <div className="panel">
      <div className="sec-title">الأشخاص <span style={{color:"var(--on-surface-3)",fontWeight:400,fontSize:13}}>· من حضر</span></div>
      <div className="chips">
        {faces.map((f,i)=>(
          <button className="facechip" key={i} onClick={()=>onFace(f)}>
            <span className="face" style={window.phStyle(f.tone)}/>
            <span>{f.name}</span>
          </button>
        ))}
      </div>
      <div className="sec-title">اللحظات</div>
      <div className="albgrid">
        {cats.map((c,i)=>(
          <div className="album" key={i}>
            <div className="cover" style={window.phStyle(c.tone)}>
              <div style={{position:"absolute",inset:0,background:"linear-gradient(0deg,rgba(0,0,0,.5),transparent 60%)"}}/>
              <b style={{position:"absolute",bottom:10,insetInlineStart:12,color:"#fff",fontSize:16}}>{c.label}</b>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------- Library tab ---------- */
function LibraryTab(){
  const albums=window.G_ALBUMS;
  return (
    <div className="panel">
      <div className="lib-row">
        <span className="lib-ic"><M2.fav s={22}/></span>
        <div style={{flex:1}}><div className="t">المفضّلة</div><div className="s">٢٤ عنصر</div></div>
      </div>
      <div className="lib-row">
        <span className="lib-ic"><M2.trash2 s={22}/></span>
        <div style={{flex:1}}><div className="t">المحذوفات</div><div className="s">يُحذف بعد ٦٠ يوم</div></div>
      </div>
      <div className="sec-title">الألبومات</div>
      <div className="albgrid">
        {albums.map((a,i)=>(
          <div className="album" key={i}>
            <div className="cover" style={window.phStyle(a.tone)}/>
            <div className="meta"><b>{a.name}</b><span>{a.count} عنصر</span></div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ====================== ROOT ====================== */
function Gallery(){
  const [theme,setTheme]=gS("light");
  const [density,setDensity]=gS("comfortable");
  const [tab,setTab]=gS("photos");
  const [selecting,setSelecting]=gS(false);
  const [sel,setSel]=gS(()=>new Set());
  const [favs,setFavs]=gS(()=>{
    const s=new Set();
    window.GALLERY_GROUPS.forEach(g=>g.items.forEach(it=>{ if(it.fav) s.add(it.id); }));
    return s;
  });
  const [photo,setPhoto]=gS(null);
  const [toast,setToast]=gS(null);
  const toastT=gR(null);

  gE(()=>{ document.documentElement.setAttribute("data-theme",theme); },[theme]);

  const flash=(msg)=>{ setToast(msg); clearTimeout(toastT.current); toastT.current=setTimeout(()=>setToast(null),2600); };

  const enterSelect=(id)=>{ setSelecting(true); setSel(new Set([id])); if(navigator.vibrate) navigator.vibrate(8); };
  const toggle=(id)=> setSel(s=>{ const n=new Set(s); n.has(id)?n.delete(id):n.add(id); if(n.size===0) setSelecting(false); return n; });
  const selectAll=(g,on)=> setSel(s=>{ const n=new Set(s); g.items.forEach(it=> on?n.add(it.id):n.delete(it.id)); if(n.size===0) setSelecting(false); return n; });
  const clearSel=()=>{ setSel(new Set()); setSelecting(false); };

  const toggleFav=(id)=> setFavs(f=>{ const n=new Set(f); n.has(id)?n.delete(id):n.add(id); return n; });

  const doAction=(label)=>{ const c=sel.size; flash(`${label} ${trG(c)} ${c===1?"عنصر":"عناصر"}`); if(label==="حذف"){} clearSel(); };

  return (
    <div className={`app ${selecting?"selecting":""}`}>
      {/* selection top bar */}
      <div className={`selbar ${selecting?"on":""}`}>
        <button className="selbar-btn" onClick={clearSel}><M2.close s={24}/></button>
        <span className="count">{trG(sel.size)}</span>
        <button className="selbar-btn" onClick={()=>doAction("مشاركة")}><M2.share s={22}/></button>
        <button className="selbar-btn" onClick={()=>doAction("أُضيف إلى ألبوم")}><M2.add s={22}/></button>
        <button className="selbar-btn" onClick={()=>doAction("حذف")}><M2.trash s={22}/></button>
      </div>

      {/* header (hidden while selecting) */}
      {!selecting && tab==="photos" &&
        <header className="hd">
          <div className="searchbar">
            <span className="mi"><M2.search s={22}/></span>
            <input placeholder="ابحث في الصور" onFocus={()=>setTab("search")}/>
            <button className="hd-icon" onClick={()=>setTheme(t=>t==="light"?"dark":"light")} aria-label="السمة">
              {theme==="light"?<M2.moon s={20}/>:<M2.sun s={20}/>}
            </button>
            <span className="avatar">ع</span>
          </div>
          <div className="toolbar">
            <span className="toolbar-title">ذكريات الزفاف · {trG(491)} لحظة</span>
            <div className="toolbar-actions">
              <DensitySeg value={density} onChange={setDensity}/>
            </div>
          </div>
        </header>}

      {/* search/library header */}
      {!selecting && tab!=="photos" &&
        <header className="hd">
          <div className="searchbar">
            <span className="mi"><M2.search s={22}/></span>
            <input placeholder={tab==="search"?"ابحث عن أشخاص أو لحظات":"ابحث في المكتبة"}/>
            <button className="hd-icon" onClick={()=>setTheme(t=>t==="light"?"dark":"light")}>
              {theme==="light"?<M2.moon s={20}/>:<M2.sun s={20}/>}
            </button>
            <span className="avatar">ع</span>
          </div>
        </header>}

      {/* feed */}
      {tab==="photos" &&
        <div className="feed">
          {window.GALLERY_GROUPS.map(g=>(
            <window.GGroup key={g.key} g={g} density={density}
              selecting={selecting} selectedSet={sel}
              onTap={setPhoto} onLongPress={enterSelect} onToggle={toggle} onSelectAll={selectAll}/>
          ))}
        </div>}
      {tab==="search" && <SearchTab onFace={(f)=>{ setTab("photos"); flash(`صور ${f.name}`); }}/>}
      {tab==="library" && <LibraryTab/>}

      {/* photo view */}
      {photo &&
        <PhotoView item={photo} onClose={()=>setPhoto(null)}
          fav={favs.has(photo.id)} onFav={()=>toggleFav(photo.id)}/>}

      {/* toast */}
      {toast && <div className="gtoast">{toast}{toast.includes("حذف")&&<b>تراجع</b>}</div>}

      {/* bottom nav (hidden while selecting/photo) */}
      {!selecting && !photo && <Nav tab={tab} onTab={setTab}/>}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("groot")).render(<Gallery/>);
