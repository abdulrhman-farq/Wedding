/* ============================================================
   Gallery data — wedding photos grouped by date
   Photographic gradient placeholders (swap for real <img> later)
   ============================================================ */

// Photographic placeholder: layered gradients evoke real photos.
// To use REAL images: replace `ph` gradient with <img src="..."> in Tile.
function tone(a,b,c){
  return `radial-gradient(120% 90% at 30% 20%, ${a}, transparent 60%),
          radial-gradient(100% 80% at 80% 90%, ${b}, transparent 65%),
          linear-gradient(160deg, ${c})`;
}
const T = {
  goldenHour: tone("rgba(255,196,120,.9)","rgba(120,60,40,.8)","#3a2414,#1a0f08"),
  emerald:    tone("rgba(80,170,130,.8)","rgba(20,60,45,.9)","#13362a,#0a1c15"),
  blush:      tone("rgba(230,170,160,.85)","rgba(120,60,70,.7)","#3a1f24,#180d10"),
  candle:     tone("rgba(245,210,150,.9)","rgba(90,55,20,.85)","#2c1d0c,#140d05"),
  ivory:      tone("rgba(245,238,220,.8)","rgba(170,150,110,.6)","#cabfa0,#6b6048"),
  bloom:      tone("rgba(220,150,170,.8)","rgba(90,40,70,.7)","#3a2030,#1a0e16"),
  night:      tone("rgba(120,150,210,.6)","rgba(180,150,90,.5)","#1a2030,#0a0d14"),
  sky:        tone("rgba(150,190,230,.7)","rgba(230,200,150,.5)","#1f2a38,#10161f"),
  rose:       tone("rgba(235,160,140,.85)","rgba(110,50,40,.7)","#3a1d16,#180c08"),
  sage:       tone("rgba(170,200,150,.7)","rgba(60,90,60,.7)","#27331f,#131a0f"),
  amber:      tone("rgba(255,180,90,.85)","rgba(120,70,20,.8)","#33200a,#160e04"),
  pearl:      tone("rgba(230,225,235,.7)","rgba(150,140,170,.5)","#b8b2c4,#5a5468"),
  wine:       tone("rgba(180,80,90,.7)","rgba(60,20,30,.85)","#2e1117,#15080b"),
  mint:       tone("rgba(160,215,195,.7)","rgba(40,90,75,.7)","#1c3a30,#0e1d18"),
  dusk:       tone("rgba(240,160,110,.8)","rgba(70,60,110,.6)","#2a2236,#13101c")
};
const TONES = Object.keys(T);

const cap = (ar,en)=>({ar,en});
function mk(id, t, type, dur, fav, ar, en){
  return {id, tone:t, type:type||"photo", dur, fav:!!fav, ...cap(ar,en)};
}
let _n=0; const uid=(p)=>`${p}${(++_n).toString().padStart(2,"0")}`;

window.GALLERY_GROUPS = [
  {
    key:"today", title:"اليوم", titleEn:"Today",
    items:[
      mk(uid("t"),"goldenHour","photo",null,true,"أوّل نظرة","First look"),
      mk(uid("t"),"candle","video","٠:٤٨",false),
      mk(uid("t"),"blush",null,null,true,"القهوة والورد","Coffee & roses"),
      mk(uid("t"),"emerald","photo",null,false),
      mk(uid("t"),"ivory","photo",null,true),
      mk(uid("t"),"amber","photo",null,false),
      mk(uid("t"),"rose","video","١:١٢",true),
      mk(uid("t"),"bloom","photo",null,false),
      mk(uid("t"),"night","photo",null,false),
      mk(uid("t"),"sky","photo",null,true),
      mk(uid("t"),"sage","photo",null,false),
      mk(uid("t"),"dusk","photo",null,false)
    ]
  },
  {
    key:"yesterday", title:"أمس", titleEn:"Yesterday",
    items:[
      mk(uid("y"),"dusk","photo",null,true,"تحت ضوء المغرب","Under the sunset"),
      mk(uid("y"),"wine","photo",null,false),
      mk(uid("y"),"amber","video","٢:٠٥",true),
      mk(uid("y"),"pearl","photo",null,false),
      mk(uid("y"),"emerald","photo",null,false),
      mk(uid("y"),"goldenHour","photo",null,true),
      mk(uid("y"),"mint","photo",null,false),
      mk(uid("y"),"blush","photo",null,false),
      mk(uid("y"),"candle","photo",null,true)
    ]
  },
  {
    key:"week", title:"هذا الأسبوع", titleEn:"Earlier this week",
    items:[
      mk(uid("w"),"ivory","photo",null,false,"الكعكة","The cake"),
      mk(uid("w"),"rose","photo",null,true),
      mk(uid("w"),"night","video","٠:٣٦",false),
      mk(uid("w"),"sky","photo",null,false),
      mk(uid("w"),"sage","photo",null,false),
      mk(uid("w"),"bloom","photo",null,true),
      mk(uid("w"),"amber","photo",null,false),
      mk(uid("w"),"emerald","photo",null,false)
    ]
  },
  {
    key:"may", title:"مايو ٢٠٢٦", titleEn:"May 2026",
    items:[
      mk(uid("m"),"goldenHour","photo",null,true,"بين الأهل","Among loved ones"),
      mk(uid("m"),"pearl","photo",null,false),
      mk(uid("m"),"wine","photo",null,false),
      mk(uid("m"),"mint","video","١:٢٤",true),
      mk(uid("m"),"blush","photo",null,false),
      mk(uid("m"),"candle","photo",null,false),
      mk(uid("m"),"dusk","photo",null,true),
      mk(uid("m"),"sky","photo",null,false),
      mk(uid("m"),"sage","photo",null,false),
      mk(uid("m"),"rose","photo",null,false),
      mk(uid("m"),"ivory","photo",null,true),
      mk(uid("m"),"night","photo",null,false)
    ]
  }
];

window.G_TONE = T;

// People (faces) for Search tab
window.G_FACES = [
  {name:"رويدا", tone:"blush"}, {name:"عبدالرحمن", tone:"emerald"},
  {name:"نورة", tone:"bloom"}, {name:"سارة", tone:"amber"},
  {name:"فيصل", tone:"sky"}, {name:"أم رويدا", tone:"rose"},
  {name:"العمّ سعد", tone:"sage"}
];
// Search categories
window.G_CATS = [
  {label:"الزفّة", tone:"candle"}, {label:"العقد", tone:"goldenHour"},
  {label:"الورود", tone:"bloom"}, {label:"الكعكة", tone:"ivory"},
  {label:"الرقص", tone:"night"}, {label:"العشاء", tone:"wine"}
];
window.G_ALBUMS = [
  {name:"المفضّلة", count:"٢٤", tone:"goldenHour"},
  {name:"الزفاف الكامل", count:"٤٩١", tone:"emerald"},
  {name:"العائلة", count:"٨٦", tone:"blush"},
  {name:"الفيديوهات", count:"١٧", tone:"night"}
];

window.toArG = (n)=> String(n).replace(/\d/g, d => "٠١٢٣٤٥٦٧٨٩"[d]);
