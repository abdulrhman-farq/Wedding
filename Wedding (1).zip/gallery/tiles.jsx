/* ============================================================
   Wedding Gallery — Material Design 3 app
   ============================================================ */
const { useState, useRef, useEffect, useCallback, useMemo } = React;
const tr = window.toArG;

/* ---------- Material icons (filled/outlined SVG) ---------- */
const M = {
  search:(p)=> <svg viewBox="0 0 24 24" width={p.s||24} height={p.s||24} fill="currentColor"><path d="M15.5 14h-.79l-.28-.27a6.5 6.5 0 1 0-.7.7l.27.28v.79l5 5 1.49-1.5-5-4.99zm-6 0A4.5 4.5 0 1 1 14 9.5 4.5 4.5 0 0 1 9.5 14z"/></svg>,
  photoF:(p)=> <svg viewBox="0 0 24 24" width={p.s||24} height={p.s||24} fill="currentColor"><path d="M19 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2zM5 19l3.5-4.5 2.5 3 3.5-4.5L19 19H5z"/></svg>,
  photoO:(p)=> <svg viewBox="0 0 24 24" width={p.s||24} height={p.s||24} fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="8.5" cy="9" r="1.6" fill="currentColor" stroke="none"/><path d="M4 18l5-5 3 3 3.5-4L20 18"/></svg>,
  searchO:(p)=> <svg viewBox="0 0 24 24" width={p.s||24} height={p.s||24} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>,
  libF:(p)=> <svg viewBox="0 0 24 24" width={p.s||24} height={p.s||24} fill="currentColor"><path d="M4 6H2v14a2 2 0 0 0 2 2h14v-2H4V6zm16-4H8a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2zm-1 9l-2.5-1.8L13 11V4h6v7z"/></svg>,
  libO:(p)=> <svg viewBox="0 0 24 24" width={p.s||24} height={p.s||24} fill="none" stroke="currentColor" strokeWidth="2" strokeLinejoin="round"><rect x="6" y="2" width="16" height="16" rx="2"/><path d="M2 6v14a2 2 0 0 0 2 2h14"/></svg>,
  check:(p)=> <svg viewBox="0 0 24 24" width={p.s||16} height={p.s||16} fill="none" stroke="currentColor" strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12.5l4.5 4.5L19 7"/></svg>,
  close:(p)=> <svg viewBox="0 0 24 24" width={p.s||24} height={p.s||24} fill="currentColor"><path d="M19 6.4 17.6 5 12 10.6 6.4 5 5 6.4 10.6 12 5 17.6 6.4 19 12 13.4 17.6 19 19 17.6 13.4 12z"/></svg>,
  share:(p)=> <svg viewBox="0 0 24 24" width={p.s||24} height={p.s||24} fill="currentColor"><path d="M18 16a3 3 0 0 0-2 .8l-7-4a3 3 0 0 0 0-1.6l7-4A3 3 0 1 0 15 5l-7 4a3 3 0 1 0 0 6l7 4a3 3 0 1 0 3-3z"/></svg>,
  add:(p)=> <svg viewBox="0 0 24 24" width={p.s||24} height={p.s||24} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><rect x="3" y="3" width="18" height="18" rx="3"/><path d="M12 8v8M8 12h8"/></svg>,
  trash:(p)=> <svg viewBox="0 0 24 24" width={p.s||24} height={p.s||24} fill="currentColor"><path d="M6 19a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>,
  more:(p)=> <svg viewBox="0 0 24 24" width={p.s||24} height={p.s||24} fill="currentColor"><circle cx="12" cy="5" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="19" r="2"/></svg>,
  play:(p)=> <svg viewBox="0 0 24 24" width={p.s||16} height={p.s||16} fill="currentColor"><path d="M8 5v14l11-7z"/></svg>,
  heart:(p)=> <svg viewBox="0 0 24 24" width={p.s||16} height={p.s||16} fill="currentColor"><path d="M12 21s-7.5-5-7.5-10.2A3.8 3.8 0 0 1 12 7a3.8 3.8 0 0 1 7.5 3.8C19.5 16 12 21 12 21z"/></svg>,
  sun:(p)=> <svg viewBox="0 0 24 24" width={p.s||22} height={p.s||22} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="12" cy="12" r="4.2"/><path d="M12 2v2.5M12 19.5V22M2 12h2.5M19.5 12H22M4.9 4.9l1.8 1.8M17.3 17.3l1.8 1.8M19.1 4.9l-1.8 1.8M6.7 17.3l-1.8 1.8"/></svg>,
  moon:(p)=> <svg viewBox="0 0 24 24" width={p.s||22} height={p.s||22} fill="currentColor"><path d="M12.5 3a7 7 0 1 0 8.5 8.5A9 9 0 1 1 12.5 3z"/></svg>,
  gridC:(p)=> <svg viewBox="0 0 24 24" width={p.s||18} height={p.s||18} fill="currentColor"><rect x="2" y="2" width="4.2" height="4.2" rx="1"/><rect x="9.9" y="2" width="4.2" height="4.2" rx="1"/><rect x="17.8" y="2" width="4.2" height="4.2" rx="1"/><rect x="2" y="9.9" width="4.2" height="4.2" rx="1"/><rect x="9.9" y="9.9" width="4.2" height="4.2" rx="1"/><rect x="17.8" y="9.9" width="4.2" height="4.2" rx="1"/><rect x="2" y="17.8" width="4.2" height="4.2" rx="1"/><rect x="9.9" y="17.8" width="4.2" height="4.2" rx="1"/><rect x="17.8" y="17.8" width="4.2" height="4.2" rx="1"/></svg>,
  gridM:(p)=> <svg viewBox="0 0 24 24" width={p.s||18} height={p.s||18} fill="currentColor"><rect x="2" y="2" width="6.5" height="6.5" rx="1.2"/><rect x="11" y="2" width="6.5" height="6.5" rx="1.2"/><rect x="2" y="11" width="6.5" height="6.5" rx="1.2"/><rect x="11" y="11" width="6.5" height="6.5" rx="1.2"/></svg>,
  gridL:(p)=> <svg viewBox="0 0 24 24" width={p.s||18} height={p.s||18} fill="currentColor"><rect x="3" y="3" width="18" height="18" rx="2"/></svg>,
  back:(p)=> <svg viewBox="0 0 24 24" width={p.s||24} height={p.s||24} fill="currentColor"><path d="M20 11H7.8l5.6-5.6L12 4l-8 8 8 8 1.4-1.4L7.8 13H20z"/></svg>,
  fav:(p)=> <svg viewBox="0 0 24 24" width={p.s||22} height={p.s||22} fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 21s-7.5-5-7.5-10.2A3.8 3.8 0 0 1 12 7a3.8 3.8 0 0 1 7.5 3.8C19.5 16 12 21 12 21z"/></svg>,
  trash2:(p)=> <svg viewBox="0 0 24 24" width={p.s||22} height={p.s||22} fill="none" stroke="currentColor" strokeWidth="2" strokeLinejoin="round"><path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/></svg>,
  album:(p)=> <svg viewBox="0 0 24 24" width={p.s||22} height={p.s||22} fill="none" stroke="currentColor" strokeWidth="2" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 15l5-5 4 4 3-3 6 6"/></svg>
};

const phStyle = (toneKey)=> ({ background: window.G_TONE[toneKey] || window.G_TONE.candle });

/* ---------- Tile ---------- */
function Tile({ item, density, selecting, selected, onTap, onLongPress, onToggle }){
  const timer = useRef(null);
  const moved = useRef(false);
  const down = (e)=>{ moved.current=false; timer.current=setTimeout(()=>{ onLongPress(item.id); }, 380); };
  const up = ()=>{ clearTimeout(timer.current); };
  const move = ()=>{ moved.current=true; clearTimeout(timer.current); };
  const click = ()=>{ if(selecting){ onToggle(item.id); } else { onTap(item); } };

  return (
    <div className={`tile ${selected?"sel":""}`} onClick={click}
      onPointerDown={down} onPointerUp={up} onPointerMove={move} onPointerLeave={up}
      role="button" aria-pressed={selected}>
      <div className="media">
        <div className="ph" style={phStyle(item.tone)} />
        {selected && <div className="scrim-sel" />}
      </div>
      <span className="check"><M.check s={14}/></span>
      {item.type==="video" && <>
        <span className="vchip"><M.play s={13}/></span>
        {item.dur && density!=="compact" && <span className="vdur">{item.dur}</span>}
      </>}
      {item.fav && !selecting && density!=="compact" && <span className="fav-dot"><M.heart s={15}/></span>}
    </div>
  );
}

/* ---------- Date group ---------- */
function Group({ g, density, selecting, selectedSet, onTap, onLongPress, onToggle, onSelectAll }){
  const allSel = g.items.every(it=> selectedSet.has(it.id));
  return (
    <section className="group">
      <div className="date-head">
        <h2>{g.title}</h2>
        <span className="cnt">{tr(g.items.length)}</span>
        {selecting &&
          <button className="selall" onClick={()=>onSelectAll(g, !allSel)}>
            {allSel? "إلغاء" : "تحديد الكل"}
          </button>}
      </div>
      <div className={`grid d-${density}`}>
        {g.items.map(it=>(
          <Tile key={it.id} item={it} density={density}
            selecting={selecting} selected={selectedSet.has(it.id)}
            onTap={onTap} onLongPress={onLongPress} onToggle={onToggle}/>
        ))}
      </div>
    </section>
  );
}

window.GTile = Tile;
window.GGroup = Group;
window.GM = M;
window.phStyle = phStyle;
