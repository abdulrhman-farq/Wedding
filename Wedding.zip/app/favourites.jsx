/* ============================================================
   Screens: End · Favourites
   ============================================================ */
const { useState:uS3, useRef:uR3 } = React;

/* -------------------- END SCREEN -------------------- */
function EndScreen({ lovedCount, superCount, attendees, onFavourites, onShare, onRestart }){
  return (
    <div className="screen end" dir="rtl">
      <div className="end-frame">
        <div className="enter" style={{"--d":"0ms"}}><Monogram size={58}/></div>
        <div className="enter" style={{"--d":"100ms"}}>
          <h2 className="end-title goldleaf">شفت كل اللحظات</h2>
          <div className="end-sub eng">You’ve seen them all</div>
        </div>

        <div className="enter end-stat" style={{"--d":"220ms"}}>
          <div className="end-count goldleaf">{window.toAr(lovedCount)}</div>
          <div className="end-count-label">
            لحظة أحببتها
            <span className="end-superline">
              <Ic.star s={13} fill="currentColor"/> {window.toAr(superCount)} لحظة مميّزة
            </span>
          </div>
        </div>

        {attendees.length>0 &&
          <div className="enter attendees" style={{"--d":"320ms"}}>
            <div className="attendees-label">من حضر معنا <span className="eng">· Who was here</span></div>
            <div className="attendees-row">
              {attendees.slice(0,7).map((a,i)=>(
                <span className="att-chip" key={i} style={{"--i":i}}>
                  <span className="att-ava">{a.charAt(0)}</span>{a}
                </span>
              ))}
              {attendees.length>7 && <span className="att-more">+{window.toAr(attendees.length-7)}</span>}
            </div>
          </div>}

        <div className="enter end-actions" style={{"--d":"440ms"}}>
          <button className="btn btn-primary" onClick={onFavourites}>
            <Ic.heart s={18} fill="currentColor"/> عرض المفضّلة <span className="eng">· Favourites</span>
          </button>
          <div className="end-actions-row">
            <button className="btn btn-ghost" onClick={onShare}><Ic.share s={18}/> مشاركة</button>
            <button className="btn btn-ghost" onClick={onRestart}><Ic.rewind s={18}/> إعادة</button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* -------------------- FAVOURITES -------------------- */
function Favourites({ favs, supers, onBack, onOpen, toast }){
  const [copied, setCopied] = uS3(false);
  const copyLink = ()=>{
    setCopied(true);
    toast({msg:"تم نسخ الرابط ✓", icon:<Ic.check s={16}/>});
    setTimeout(()=>setCopied(false), 2200);
  };
  const isEmpty = favs.length===0;

  return (
    <div className="screen favs" dir="rtl">
      <header className="favs-head">
        <button className="icon-btn" onClick={onBack} aria-label="رجوع"><Ic.back s={22}/></button>
        <div className="favs-title">
          <h2 className="goldleaf">المفضّلة</h2>
          <span className="favs-count">{window.toAr(favs.length)} لحظة</span>
        </div>
        <button className="icon-btn" onClick={()=>toast({msg:"تم حفظ الكل", icon:<Ic.download s={16}/>})}
          aria-label="حفظ الكل" disabled={isEmpty}><Ic.download s={20}/></button>
      </header>

      <div className="favs-share">
        <button className="share-btn wa" onClick={()=>toast({msg:"مشاركة عبر واتساب", icon:<Ic.whatsapp s={16}/>})}>
          <Ic.whatsapp s={18}/> واتساب
        </button>
        <button className={`share-btn ${copied?"copied":""}`} onClick={copyLink}>
          {copied ? <><Ic.check s={16}/> تم النسخ ✓</> : <><Ic.link s={17}/> نسخ الرابط</>}
        </button>
      </div>

      {isEmpty ? (
        <div className="favs-empty">
          <div className="empty-ring"><Ic.heart s={30}/></div>
          <div className="empty-ar">لا توجد لحظات مفضّلة بعد</div>
          <div className="empty-en eng">No favourites yet — swipe right to love a moment</div>
          <button className="btn btn-ghost" onClick={onBack}>تصفّح الذكريات</button>
        </div>
      ) : (
        <div className="favs-grid">
          {favs.map(m=>(
            <button className="tile" key={m.id} onClick={()=>onOpen(m)}>
              <MediaArt sceneKey={m.scene} type={m.type} small/>
              <div className="tile-veil"/>
              {supers.has(m.id) && <span className="tile-star"><Ic.star s={13} fill="currentColor"/></span>}
              {m.type==="video" && <span className="tile-play"><Ic.play s={11}/></span>}
              <span className="tile-cap">{m.ar}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

window.EndScreen = EndScreen;
window.Favourites = Favourites;
