/* ============================================================
   Screens: Landing · Lightbox · End · Favourites
   ============================================================ */
const { useState:uS, useRef:uR, useEffect:uE } = React;

/* -------------------- LANDING / COVER -------------------- */
function Landing({ onStart, loading }){
  return (
    <div className="screen landing" dir="rtl">
      <div className="landing-frame">
        <div className="enter" style={{"--d":"0ms"}}>
          <div className="basmala">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</div>
        </div>
        <div className="enter" style={{"--d":"90ms"}}><Orn/></div>

        <div className="enter" style={{"--d":"180ms"}}>
          <div className="families goldleaf">النقيدان و المحيسن</div>
        </div>
        <div className="enter" style={{"--d":"300ms"}}>
          <h1 className="couple goldleaf">عبدالرحمن &amp; رويدا</h1>
        </div>
        <div className="enter eng couple-en" style={{"--d":"380ms"}}>Abdulrhman &amp; Ruwaida</div>

        <div className="enter" style={{"--d":"480ms"}}><Monogram size={66}/></div>

        <div className="enter date-line" style={{"--d":"560ms"}}>
          ٢٨–٢٩ مايو ٢٠٢٦ <span className="middot">·</span> الرياض
        </div>

        <div className="enter swipe-hint" style={{"--d":"660ms"}}>
          اسحب لتتصفّح ذكرياتنا
          <span className="hint-en eng">Swipe through our memories</span>
        </div>

        <div className="enter" style={{"--d":"760ms"}}>
          <button className="btn btn-primary landing-cta" onClick={onStart} disabled={loading}>
            {loading ? <span className="dots"><i/><i/><i/></span> : <>ابدأ <span className="eng cta-en">· Start</span></>}
          </button>
        </div>
      </div>
      <div className="landing-foot enter" style={{"--d":"900ms"}}>
        <Ic.heart s={13}/> صُنع بحبّ لأحبّتنا
      </div>
    </div>
  );
}

/* -------------------- LIGHTBOX / DETAIL -------------------- */
function Lightbox({ mem, onClose, onToggleFav, isFav, tags, addTag, toast }){
  const [tagMode, setTagMode] = uS(false);
  const [pending, setPending] = uS(null); // {x,y}
  const [name, setName] = uS("");
  const stageRef = uR(null);
  const inputRef = uR(null);

  const onStageClick = (e)=>{
    if(!tagMode) return;
    const r = stageRef.current.getBoundingClientRect();
    const x = ((e.clientX - r.left)/r.width)*100;
    const y = ((e.clientY - r.top)/r.height)*100;
    setPending({x,y}); setName("");
    setTimeout(()=> inputRef.current && inputRef.current.focus(), 30);
  };
  const commit = ()=>{
    if(name.trim() && pending){ addTag(mem.id, {x:pending.x, y:pending.y, name:name.trim()}); }
    setPending(null); setName("");
  };

  const memTags = tags[mem.id] || [];

  return (
    <div className="lightbox" dir="rtl" role="dialog" aria-modal="true">
      <div className="lb-backdrop" onClick={onClose}/>
      <button className="lb-close" onClick={onClose} aria-label="إغلاق"><Ic.close s={22}/></button>

      <div className="lb-shell">
        <div className={`lb-stage ${tagMode?"tagging":""}`} ref={stageRef} onClick={onStageClick}>
          <MediaArt sceneKey={mem.scene} type={mem.type} dur={mem.dur}/>

          {memTags.map((t,i)=>(
            <div className="pin" key={i} style={{left:`${t.x}%`, top:`${t.y}%`}}>
              <span className="pin-dot"/>
              <span className="pin-label">{t.name}</span>
            </div>
          ))}

          {pending &&
            <div className="pin pin-pending" style={{left:`${pending.x}%`, top:`${pending.y}%`}}>
              <span className="pin-dot"/>
              <div className="pin-input">
                <input ref={inputRef} value={name} onChange={e=>setName(e.target.value)}
                  placeholder="الاسم · Name"
                  onKeyDown={e=> e.key==="Enter" && commit()}/>
                <button onClick={commit} aria-label="حفظ"><Ic.check s={16}/></button>
              </div>
            </div>}

          <div className="lb-topbar">
            <MediaBadge type={mem.type} dur={mem.dur}/>
            <button className={`lb-fav ${isFav?"on":""}`} onClick={()=>onToggleFav(mem)} aria-label="أحب">
              <Ic.heart s={20} fill={isFav?"currentColor":"none"}/>
            </button>
          </div>

          <div className="lb-caption">
            <div className="card-cap-ar">{mem.ar}</div>
            <div className="card-cap-en eng">{mem.en}</div>
          </div>
        </div>

        <div className="lb-controls">
          <button className={`chip ${tagMode?"chip-on":""}`} onClick={()=>{setTagMode(v=>!v); setPending(null);}}>
            <Ic.tag s={17}/> وسم <span className="eng">· Tag</span>
            {memTags.length>0 && <span className="chip-count">{window.toAr(memTags.length)}</span>}
          </button>
          {mem.type==="video" &&
            <button className="chip" onClick={()=>toast({msg:"يُفتح في Google Drive", icon:<Ic.play s={15}/>})}>
              <Ic.play s={15}/> تشغيل من Drive
            </button>}
          <button className="chip" onClick={()=>toast({msg:"تم حفظ الصورة", icon:<Ic.download s={16}/>})}>
            <Ic.download s={17}/> حفظ
          </button>
        </div>

        <div className="lb-hint">
          {tagMode
            ? <>انقر على الصورة لإضافة شخص <span className="eng">· Tap photo to tag a person</span></>
            : <>فعّل الوسم لتعريف الحضور <span className="eng">· Turn on Tag to mark who’s here</span></>}
        </div>
      </div>
    </div>
  );
}

window.Landing = Landing;
window.Lightbox = Lightbox;
